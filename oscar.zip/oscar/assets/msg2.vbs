Dim voice
Set voice = CreateObject("SAPI.SpVoice")

voice.Speak "well. now i think it is time i actually do some stuff and delete all your pre downloaded files from you."