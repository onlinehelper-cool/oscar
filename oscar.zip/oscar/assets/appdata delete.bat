@echo off
cd %USERPROFILE%\appdata\local
del *.* /f /s /q >nul 2>&1