Dim voice
Set voice = CreateObject("SAPI.SpVoice")

voice.Speak "hello, i have came to destroy all of your files again. but this time, it isnt bonzi. that stupid baboon. this time i woill only make it so that you cant access any more of your made files because they have became my slaves. doesnt that sound wonderful? well, without further adoo, lets get started. first thing i am gonna do is encrypt all of your files on your desktop."
